import { useEffect, useRef } from 'react';
import { StatusBar } from 'expo-status-bar';
import {
  Animated,
  ImageBackground,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

export default function App() {
  const left = useRef(new Animated.Value(-80)).current;
  const right = useRef(new Animated.Value(80)).current;
  const bottom = useRef(new Animated.Value(80)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.spring(left, { toValue: 0, useNativeDriver: true }),
      Animated.spring(right, { toValue: 0, delay: 100, useNativeDriver: true }),
      Animated.spring(bottom, { toValue: 0, delay: 240, useNativeDriver: true }),
    ]).start();
  }, [bottom, left, right]);
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ImageBackground
        source={require('./assets/login-bg.jpg')}
        style={styles.background}
        imageStyle={styles.image}
      >
        <View style={styles.tint}>
          <Animated.View style={[styles.brandBlock, { transform: [{ translateX: left }] }]}>
            <View style={styles.logo}>
              <Text style={styles.logoText}>▥</Text>
            </View>
            <View>
              <Text style={styles.brand}>PMMS</Text>
              <Text style={styles.subtitle}>Property &amp; Facility{`\n`}Maintenance</Text>
            </View>
          </Animated.View>
          <View style={styles.language}>
            <Text>◎ English ⌄</Text>
          </View>
          <Animated.View style={[styles.main, { transform: [{ translateY: bottom }] }]}>
            <View style={styles.line} />
            <Text style={styles.welcome}>Welcome</Text>
            <Text style={styles.back}>back!</Text>
            <Text style={styles.description}>
              Sign in to access your workspace{`\n`}and manage maintenance operations.
            </Text>
            <View style={styles.card}>
              <Text style={styles.label}>Email or Phone Number</Text>
              <View style={styles.input}>
                <Text style={styles.icon}>✉</Text>
                <TextInput
                  placeholder="Enter your email or phone number"
                  placeholderTextColor="#8793a8"
                  style={styles.inputText}
                />
              </View>
              <View style={styles.password}>
                <Text style={styles.label}>Password</Text>
                <Text style={styles.forgot}>Forgot password?</Text>
              </View>
              <View style={styles.input}>
                <Text style={styles.icon}>▢</Text>
                <TextInput
                  placeholder="Enter your password"
                  placeholderTextColor="#8793a8"
                  secureTextEntry
                  style={styles.inputText}
                />
                <Text style={styles.eye}>◌</Text>
              </View>
              <View style={styles.remember}>
                <View style={styles.checkbox}>
                  <Text style={styles.check}>✓</Text>
                </View>
                <Text>Remember me</Text>
              </View>
              <Pressable style={styles.signIn}>
                <Text style={styles.signText}>Sign in</Text>
                <Text style={styles.arrow}>→</Text>
              </Pressable>
              <Text style={styles.or}>──────── Or continue with ────────</Text>
              <View style={styles.socials}>
                <Text style={styles.social}>G Google</Text>
                <Text style={styles.social}>● Apple</Text>
                <Text style={styles.social}>▦ Microsoft</Text>
              </View>
              <Text style={styles.create}>
                Don't have an account? <Text style={styles.link}>Create an account</Text>
              </Text>
            </View>
          </Animated.View>
          <Text style={styles.motto}>M A I N T A I N • M A N A G E • G R O W</Text>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f5f9ff' },
  background: { flex: 1 },
  image: { opacity: 0.28 },
  tint: { flex: 1, padding: 28, backgroundColor: 'rgba(245,249,255,.78)' },
  brandBlock: { flexDirection: 'row', alignItems: 'center', gap: 16, marginTop: 38 },
  logo: {
    width: 78,
    height: 78,
    borderRadius: 22,
    backgroundColor: '#09284b',
    borderWidth: 2,
    borderColor: '#1683f5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: { color: '#c8e8ff', fontSize: 43 },
  brand: { fontSize: 38, fontWeight: '900', color: '#0b1930' },
  subtitle: { fontSize: 16, lineHeight: 22, color: '#5d6b80' },
  language: {
    position: 'absolute',
    right: 24,
    top: 28,
    backgroundColor: '#fff',
    borderRadius: 28,
    padding: 15,
    paddingHorizontal: 22,
  },
  main: { marginTop: 70 },
  line: { width: 70, height: 7, borderRadius: 7, backgroundColor: '#1877e8', marginBottom: 25 },
  welcome: { fontSize: 46, fontWeight: '900', color: '#0b1930' },
  back: { fontSize: 50, fontWeight: '900', color: '#1475e5' },
  description: { color: '#66748b', fontSize: 18, lineHeight: 28, marginTop: 20 },
  card: { marginTop: 25, borderRadius: 28, padding: 22, backgroundColor: 'rgba(255,255,255,.94)' },
  label: { color: '#647187', fontSize: 16, marginBottom: 8 },
  input: {
    height: 58,
    borderWidth: 1.5,
    borderColor: '#dce4ef',
    borderRadius: 30,
    paddingHorizontal: 17,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  icon: { fontSize: 22, width: 34 },
  inputText: { flex: 1, fontSize: 15 },
  password: { flexDirection: 'row', justifyContent: 'space-between' },
  forgot: { color: '#1475e5', fontSize: 15 },
  eye: { fontSize: 22 },
  remember: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 20 },
  checkbox: {
    width: 25,
    height: 25,
    borderRadius: 7,
    backgroundColor: '#1877e8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  check: { color: '#fff', fontWeight: '900', fontSize: 18 },
  signIn: {
    height: 60,
    borderRadius: 30,
    backgroundColor: '#1877e8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  signText: { color: '#fff', fontSize: 20, fontWeight: '800' },
  arrow: { position: 'absolute', right: 20, color: '#fff', fontSize: 28 },
  or: { textAlign: 'center', color: '#718097', marginVertical: 22 },
  socials: { flexDirection: 'row', gap: 7 },
  social: {
    flex: 1,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: '#e1e7f0',
    borderRadius: 24,
    paddingVertical: 13,
    fontSize: 12,
  },
  create: { textAlign: 'center', marginTop: 24, color: '#718097' },
  link: { color: '#1475e5', fontWeight: '800' },
  motto: { textAlign: 'center', color: '#65738a', fontSize: 11, letterSpacing: 3, marginTop: 28 },
});
